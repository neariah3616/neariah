var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["e7c79562-d008-441a-befd-bdcb2c84ff25","a551e289-aa14-414d-96ef-6b5f9d9995e8","c5ea5ed4-a081-4633-b964-d19a9fb01b46","fca2734c-778d-4f4f-bc65-8f7207879c77","ed9a6452-ed57-479e-8adc-c862e643f813","507905de-bbbd-4bf9-94f5-10590f08381c"],"propsByKey":{"e7c79562-d008-441a-befd-bdcb2c84ff25":{"name":"background","sourceUrl":"assets/api/v1/animation-library/gamelab/2RNMR6.K0ycRUzGH2f_.KDC56AlzdXPI/category_backgrounds/sunshine_showers.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"2RNMR6.K0ycRUzGH2f_.KDC56AlzdXPI","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/2RNMR6.K0ycRUzGH2f_.KDC56AlzdXPI/category_backgrounds/sunshine_showers.png"},"a551e289-aa14-414d-96ef-6b5f9d9995e8":{"name":"Zombie1","sourceUrl":null,"frameSize":{"x":31,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"6OAeCFWzGAhY_36yEK933y5BTBhfo1Vx","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":31,"y":30},"rootRelativePath":"assets/a551e289-aa14-414d-96ef-6b5f9d9995e8.png"},"c5ea5ed4-a081-4633-b964-d19a9fb01b46":{"name":"Zombie2","sourceUrl":null,"frameSize":{"x":31,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"OHokgjYe6RRoYDSYNLxCviCAIiewUlxu","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":31,"y":30},"rootRelativePath":"assets/c5ea5ed4-a081-4633-b964-d19a9fb01b46.png"},"fca2734c-778d-4f4f-bc65-8f7207879c77":{"name":"Zombie3","sourceUrl":null,"frameSize":{"x":31,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"h8QtuLfHao4Rsm2onAmfhqVDDrrXnO3W","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":31,"y":30},"rootRelativePath":"assets/fca2734c-778d-4f4f-bc65-8f7207879c77.png"},"ed9a6452-ed57-479e-8adc-c862e643f813":{"name":"Human","sourceUrl":null,"frameSize":{"x":35,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"c.v_b.QZcocyNK.rIQxX2HJ5X9Dm5BZZ","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":35,"y":50},"rootRelativePath":"assets/ed9a6452-ed57-479e-8adc-c862e643f813.png"},"507905de-bbbd-4bf9-94f5-10590f08381c":{"name":"Castle","sourceUrl":null,"frameSize":{"x":63,"y":90},"frameCount":1,"looping":true,"frameDelay":12,"version":"ujEcVIkf5ThP.C4B8O_fwrcfnKpaE0Wr","categories":["buildings"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":63,"y":90},"rootRelativePath":"assets/507905de-bbbd-4bf9-94f5-10590f08381c.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var BG = createSprite(200,200);
BG.setAnimation("background");

var Castle = createSprite(50,50);
Castle.setAnimation("Castle");

var Zombie1 = createSprite(50,70,10,1);
Zombie1.setAnimation("Zombie1");

var Zombie2 = createSprite(350,200,270,5);
Zombie2.setAnimation("Zombie2");

var Zombie3 = createSprite(50,300,270,5);
Zombie3.setAnimation("Zombie3");

var Human = createSprite(185,390,10,1);
Human.setAnimation("Human"); 

  Zombie1.velocityX = 8;
  Zombie2.velocityX = -8;
  Zombie3.velocityX = 8;

function draw() {
  background("white");
  if(
    Human.isTouching(Castle))
    {
      playSound( "assets/category_hits/puzzle_game_magic_item_unlock_5.mp3");
    }
    
   if (Human.isTouching(Zombie1||Zombie2||Zombie3))
  {
      textSize(40);
  stroke("red");
  text("You Win", 200,200);
  }
  if(
     Human.isTouching(Zombie1)||
     Human.isTouching(Zombie2)||
     Human.isTouching(Zombie3))
  {
     playSound("assets/category_points/negative_point_counter_2.mp3");
      Human.x=12;
      Human.y=190;
      
  }
   
  if (keyDown(UP_ARROW)){
  Human.velocityX = 0;
  Human.velocityY = -3;
  Human.x=Human.x-2;
}
if(keyDown(DOWN_ARROW)){
  Human.velocityX = 0;
  Human.velocityY = 3;
  Human.x=Human.x+2;
}
  if (keyDown(LEFT_ARROW)){
  Human.velocityX = 0;
  Human.velocityY = -3;
  Human.x=Human.x-2;
}
if(keyDown(RIGHT_ARROW)){
  Human.velocityX = 0;
  Human.velocityY = 3;
  Human.x=Human.x+2;
}
if(Zombie1.isTouching(Human)||Zombie2.isTouching(Human)||Zombie3.isTouching(Human)){
 text("GAME OVER");
 textSize(40);
 Zombie1.setVelocity(0,0);
 Zombie2.setVelocity(0,0);
 Zombie3.setVelocity(0,0);
 Human.setVelocity(0,0);
}
  createEdgeSprites();
Zombie1.bounceOff(edges);
Zombie2.bounceOff(edges);
Zombie3.bounceOff(edges);
Human.bounceOff(edges);
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
